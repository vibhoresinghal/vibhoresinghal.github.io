# Operational preservation and recovery

Read before structural mutations. Use the current Figma skill/API documentation as the authority for supported methods; these notes address cleanup-specific decisions, not a replacement API manual.

## Snapshot outside the file

Before moving content, save a compact per-page checkpoint in the task workspace (for example `work/figma-cleanup/<file-key>/`). Include page/section IDs and names, ordered child IDs, parent IDs, local positions, dimensions, relevant render bounds, prototype starts, and affected transition targets. For moved subtrees, capture descendant IDs/types, component linkage, and text/content hashes where practical. Keep all node records even if the chat summary is compact.

This checkpoint is an inventory, not a full Figma backup. Do not claim it can restore deleted design content. Delete only verified empty source pages and explicitly authorized obsolete artifacts.

## Page loading and mutations

- Do not infer emptiness from unloaded `page.children`; unloaded pages may appear empty or incomplete. Load each page in its own inspection call.
- Follow the current tool's page-switch limits. If limited to one switch per call, fan out independent per-page reads and stage dependent writes sequentially. Do not run concurrent writes into the same destination.
- Before moving existing text-bearing subtrees, load their current fonts as required by the API. A missing font is not permission to substitute it. If container-only moves work without altering text, preserve the original font; otherwise pause only that operation and explain the blocker.
- Never assume a failed call committed or rolled back. Respect the tool's retry flag and inspect live state when uncertain. Return all affected IDs from mutations, including removed IDs.

## Consolidation procedure

1. Resolve the actual source/target IDs and relevant scope. Capture original content and prototype records.
2. If a source is already coherently sectioned, reuse its sections. Otherwise wrap related content in named native sections while preserving positions relative to one another. Avoid repeated wrapping on a second run.
3. Determine a clear destination position from the current target bounds. Prefer a compact layout of section-sized regions with consistent gaps; do not scatter whole pages across vast distances.
4. Move original nodes; do not clone. Preserve subtree order, component instances, geometry and intentional overlaps. Use rendered extents for external spacing and geometric dimensions for the design itself.
5. Transfer the source page's prototype starting points to the destination without duplicate entries. Recheck transition targets and cross-page restrictions. Keep a connected prototype together when a move would break it; adjust the organization rather than silently severing interactions.
6. Read back the moved IDs and content counts. Compare positions within each moved composition and dimensions with a small tolerance (e.g. 0.1 canvas unit). Inspect every mismatch rather than silently ignoring it. Check link targets are still resolvable.
7. Verify the source is empty after migration. Switch to a retained page before removing an empty source; some tools reject removal of the current page. If the source contains unaccounted content, retain it and resolve the discrepancy.
8. Record the source-page URL to destination-section URL mapping. Original node links generally remain useful when IDs survive, but removed page links do not. Report this distinction rather than promising all links are unchanged.

## Visual and structural checks

Inspect each affected page at composition scale, then representative dense sections at readable scale. Check section-to-section overlaps, clipped or off-canvas content, lost annotations and overcrowded widgets. Intentional within-composition overlap should not be flagged as accidental.

An overview screenshot cannot verify screen detail, fonts, animation or prototype interactions. State which checks ran. For purely sidebar changes, verify the returned names/order and preserve all existing content pages; canvas screenshots do not show sidebar ordering.

## Reruns

Store completed operations and returned node IDs. Before retrying, confirm whether the expected section exists and where each source node now lives. If partly applied, continue only the remaining moves. If current state conflicts with the checkpoint or user edits, re-inspect and update the plan instead of overwriting their work.

## Acceptance scenarios

- A page called “Final” and a later dated page coexist: ask which frame is live; do not choose by date.
- User supplies live, approved and experiment URLs: use those facts, separate live from pending approval implementation, and execute without asking for the same confirmation again.
- User requests sidebar only: rename/order category pages; do not rearrange screen internals.
- Source page appears empty before loading: load it before considering removal.
- Prototype transitions connect screens across proposed groups: preserve the connected flow or choose a different grouping.
- Two card studies overlap intentionally: move the cluster intact; do not turn it into a generic grid.
- Rerun against a completed file: reuse dividers and sections; create no duplicates.
- Multi-file batch with an inaccessible file: record that file as blocked, continue accessible authorized files, and report the boundary accurately.
